document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const hamburger = document.querySelector('.hamburger');
    const mobileNav = document.querySelector('.mobile-nav');
    
    hamburger.addEventListener('click', function() {
        this.classList.toggle('active');
        mobileNav.style.left = mobileNav.style.left === '0px' ? '-100%' : '0px';
    });
    
    // Cart functionality
    const cartIcon = document.querySelector('.cart-icon');
    const cartDropdown = document.querySelector('.cart-dropdown');
    const cartCount = document.querySelector('.cart-count');
    const addToCartBtn = document.querySelector('.add-to-cart-btn');
    const quantityDisplay = document.querySelector('.quantity');
    const incrementBtn = document.querySelector('.increment');
    const decrementBtn = document.querySelector('.decrement');
    const cartEmpty = document.querySelector('.cart-empty');
    const cartFilled = document.querySelector('.cart-filled');
    const itemQuantity = document.querySelector('.item-quantity');
    const itemTotal = document.querySelector('.item-total');
    const deleteItemBtn = document.querySelector('.delete-item');
    
    let quantity = 0;
    let cartItems = 0;
    
    // Toggle cart dropdown
    cartIcon.addEventListener('click', function(e) {
        e.stopPropagation();
        cartDropdown.style.display = cartDropdown.style.display === 'block' ? 'none' : 'block';
    });
    
    // Close cart when clicking outside
    document.addEventListener('click', function() {
        cartDropdown.style.display = 'none';
    });
    
    // Prevent cart from closing when clicking inside
    cartDropdown.addEventListener('click', function(e) {
        e.stopPropagation();
    });
    
    // Quantity selector
    incrementBtn.addEventListener('click', function() {
        quantity++;
        quantityDisplay.textContent = quantity;
    });
    
    decrementBtn.addEventListener('click', function() {
        if (quantity > 0) {
            quantity--;
            quantityDisplay.textContent = quantity;
        }
    });
    
    // Add to cart
    addToCartBtn.addEventListener('click', function() {
        if (quantity > 0) {
            cartItems = quantity;
            cartCount.textContent = cartItems;
            cartCount.style.display = 'block';
            
            // Update cart dropdown
            cartEmpty.style.display = 'none';
            cartFilled.style.display = 'block';
            itemQuantity.textContent = cartItems;
            itemTotal.textContent = `$${(125 * cartItems).toFixed(2)}`;
        }
    });
    
    // Delete item from cart
    deleteItemBtn.addEventListener('click', function() {
        cartItems = 0;
        quantity = 0;
        quantityDisplay.textContent = quantity;
        cartCount.style.display = 'none';
        
        // Update cart dropdown
        cartEmpty.style.display = 'block';
        cartFilled.style.display = 'none';
    });
    
    // Image gallery functionality
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.querySelector('.main-image img');
    
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            // Remove active class from all thumbnails
            thumbnails.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked thumbnail
            this.classList.add('active');
            
            // Update main image
            const thumbnailSrc = this.querySelector('img').src;
            const mainImageSrc = thumbnailSrc.replace('-thumbnail', '');
            mainImage.src = mainImageSrc;
        });
    });
    
    // Lightbox functionality
    const lightboxToggle = document.querySelector('.lightbox-toggle');
    const lightbox = document.querySelector('.lightbox');
    const closeLightbox = document.querySelector('.close-lightbox');
    const lightboxMainImage = document.querySelector('.lightbox .main-image img');
    const lightboxThumbnails = document.querySelectorAll('.lightbox .thumbnail');
    const prevBtn = document.querySelector('.lightbox .prev');
    const nextBtn = document.querySelector('.lightbox .next');
    
    let currentImageIndex = 0;
    
    lightboxToggle.addEventListener('click', function() {
        lightbox.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    });
    
    closeLightbox.addEventListener('click', function() {
        lightbox.style.display = 'none';
        document.body.style.overflow = 'auto';
    });
    
    // Update lightbox when clicking thumbnails
    lightboxThumbnails.forEach((thumbnail, index) => {
        thumbnail.addEventListener('click', function() {
            currentImageIndex = index;
            updateLightboxImage();
        });
    });
    
    // Navigation buttons
    prevBtn.addEventListener('click', function() {
        currentImageIndex = (currentImageIndex - 1 + thumbnails.length) % thumbnails.length;
        updateLightboxImage();
    });
    
    nextBtn.addEventListener('click', function() {
        currentImageIndex = (currentImageIndex + 1) % thumbnails.length;
        updateLightboxImage();
    });
    
    function updateLightboxImage() {
        // Update main image
        const thumbnailSrc = thumbnails[currentImageIndex].querySelector('img').src;
        const mainImageSrc = thumbnailSrc.replace('-thumbnail', '');
        lightboxMainImage.src = mainImageSrc;
        
        // Update active thumbnail
        lightboxThumbnails.forEach(t => t.classList.remove('active'));
        lightboxThumbnails[currentImageIndex].classList.add('active');
    }
    
    // Close lightbox when clicking outside
    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) {
            lightbox.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });
});